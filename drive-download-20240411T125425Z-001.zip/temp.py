#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 17 20:19:21 2020

@author: harshita
"""

import matplotlib.pyplot as plt
import numpy as np
# %matplotlib


x = [i for i in range(10)]
y = [i**2 for i in range(10)]

for i in range(len(x)):
    plt.scatter(x[i],y[i])

plt.show()
#%%
import random
import math
import matplotlib.pyplot as plt
import numpy as np
c_list=[]
error_list=[]
from math import exp,pi,sin
def func(x):
    return exp(-x)*23(sin(pi*x))*2
n=int(input('enter number:'))
for k in range (n):
    c=2**k
    x=np.zeros(c)
    c_list.append(math.log(c))
    for j in range(len(x)):
        x[j]=random.uniform(0,10)
    area=0
    for i in range(c):
        area+=func(x[i])
    value=10/float(c) * area
    print('value:',value)
    error=0.4876477384840712-value
    error_list.append(math.log(abs(error)))
plt.scatter(c_list,error_list)
plt.show()
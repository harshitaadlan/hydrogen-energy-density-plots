#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 15:44:04 2021

@author: harshita
"""


#%%
import random
import math
import matplotlib.pyplot as plt
b=[]
c=[]
total_points=[10,100,1000,10000,100000,1000000]
number_of_points_inside_the_circle = 0
number_of_points_inside_the_square =0
for j in range(len(total_points)):
    number_of_points_inside_the_circle = 0
    number_of_points_inside_the_square =0
    
    for i in range(total_points[j]):
        rand_x = random.uniform(-1, 1)
        rand_y = random.uniform(-1, 1)
        origin_dist = rand_x**2 + rand_y**2
        if origin_dist <= 1:
            number_of_points_inside_the_circle += 1
        number_of_points_inside_the_square += 1
        pi = 4 * number_of_points_inside_the_circle / number_of_points_inside_the_square
    print('TOTAL POINTS:', total_points[j])    
    print("Final Estimation of Pi=", pi)
    difference = abs(3.141592653589793238-pi)
    l_diff=math.log(difference)
    c.append(l_diff)
    print('error:',difference)
    sd=[]
    for i in range (len(total_points)):
        standard_deviation = print(((difference**2)/total_points[i])**(1/2))
        sd.append(standard_deviation)
    print(number_of_points_inside_the_circle)
    import math
    a=math.log(number_of_points_inside_the_square)
    print('Number of points inside the square',a)
    b.append(a)
plt.plot(b,c)
plt.show()
#%%
import numpy as np
import random
import math
import matplotlib.pyplot as plt
def best_fit(X, Y):

    xbar = int(sum(X)/len(X))
    ybar = int(sum(Y)/len(Y))
    n = len(X) # or len(Y)

    numer = sum([xi*yi for xi,yi in zip(X, Y)]) - n * xbar * ybar
    denum = sum([xi**2 for xi in X]) - n * xbar**2

    b = int(numer / denum)
    a = int(ybar - b * xbar)

    print('best fit line:\ny = {:.2f} + {:.2f}x'.format(a, b))

    return a, b
for k in range (5):
    b=[]
    c=[]
    total_points=[10,100,1000,10000,100000,1000000]
    number_of_points_inside_the_circle = 0
    number_of_points_inside_the_square =0
    for j in range(len(total_points)):
        number_of_points_inside_the_circle = 0
        number_of_points_inside_the_square =0
    
        for i in range(total_points[j]):
            rand_x = random.uniform(-1, 1)
            rand_y = random.uniform(-1, 1)
            origin_dist = rand_x**2 + rand_y**2
            if origin_dist <= 1:
                number_of_points_inside_the_circle += 1
            number_of_points_inside_the_square += 1
            pi = 4 * number_of_points_inside_the_circle / number_of_points_inside_the_square
        print('TOTAL POINTS:', total_points[j])    
        print("Final Estimation of Pi=", pi)
        difference = abs(3.141592653589793238-pi)
        l_diff=math.log(difference)
        c.append(l_diff)
        print('error:',difference)
        sd=[]
        for i in range (len(total_points)):
            standard_deviation = print(((difference**2)/total_points[i])**(1/2))
            sd.append(standard_deviation)
        print(number_of_points_inside_the_circle)
  
        a=math.log(number_of_points_inside_the_square)
        print('Number of points inside the square',a)
        b.append(a)
        plt.scatter(b,c)
    
        plt.show()
x, y = best_fit(a,b)
yfit = [x + y * xi for xi in a]
plt.plot(a, yfit)
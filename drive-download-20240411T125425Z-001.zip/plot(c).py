#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  7 14:16:16 2021

@author: harshita
"""


#%%
import random
import math
import matplotlib.pyplot as plt
import numpy as np
x=[]

error_list=[]
from math import exp,pi,sin
def func(x):
    return exp(-x)*(sin(pi*x))*2
n = int(input('enter number:'))
for i in range(n):
    y=random.uniform(0,1)
    l_x = abs(math.log(y))
    
    if l_x< 10:
        x.append(l_x)
area=0
for j in range(len(x)):
    area+=func(x[j])
    error=0.4876477384840712-x[j]
    error_list.append(math.log(abs(error)))
    value=10/float(len(x))*area

plt.scatter(x,error_list)
plt.show()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 30 18:57:00 2020

@author: harshita
"""


#%%
import numpy as np
from matplotlib import pyplot as plt

def phase_factor(k, nbs):    
    p,q,r,s = [np.exp(1j*k @ nb) for nb in nbs]
    pf = np.array([p+q+r+s,    p+q-r-s,    p-q+r-s,    p-q-r+s])
    return (1 / 4) * pf

def band_energy_eigval(g, E_s, E_p, V_ss, V_sp, V_xx, V_xy):
    gc = np.conjugate(g)
    H = np.array([[         E_s,  V_ss * g[0],            0,            0,            0, V_sp * g[1], V_sp * g[2], V_sp * g[3]],
                  [V_ss * gc[0],          E_s, -V_sp * gc[1], -V_sp * gc[2], -V_sp * gc[3],          0,          0,          0],
                  [          0, -V_sp * g[1],           E_p,            0,            0, V_xx * g[0], V_xy * g[3], V_xy * g[1]],
                  [          0, -V_sp * g[2],            0,           E_p,            0, V_xy * g[3], V_xx * g[0], V_xy * g[1]],
                  [          0, -V_sp * g[3],            0,            0,           E_p, V_xy * g[1], V_xy * g[2], V_xx * g[0]],
                  [V_sp * gc[1],           0,  V_xx * gc[0],  V_xy * gc[3],  V_xy * gc[1],         E_p,         0,           0],
                  [V_sp * gc[2],           0,  V_xy * gc[3],  V_xx * gc[0],  V_xy * gc[2],          0,        E_p,           0],
                  [V_sp * gc[3],           0,  V_xy * gc[1],  V_xy * gc[1],  V_xx * gc[0],          0,         0,          E_p]])
    eigen_values = np.linalg.eigvalsh(H)
    return np.sort(eigen_values)

def band_structure(par, nbs, kpath):
    bands = []
    path=np.vstack(kpath)
    for k in path:
        g=phase_factor(k,nbs)
        bands.append(band_energy_eigval(g,*par))
    return np.stack(bands, axis=-1)

def linpath(x,y,n=50, endpoint=True):
    spacings = [np.linspace(start, end, num=n, endpoint=endpoint) for start, end in zip(x,y)]
    return np.stack(spacings, axis=-1)

parameters = (-4.03, 3.17, -8.13, 5.88, 3.17, 7.51)
n = 1000
a = 1
nbs =np.array([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]])*a/4
[G,L,K,X,W,U]=(2*np.pi/a)*np.array([[0, 0, 0],[1/2, 1/2, 1/2],[3/4, 3/4, 0],[0, 0, 1],[1, 1/2, 0],[1/4, 1/4, 1]])
Lambda = linpath(L, G, n, endpoint=False)
Delta = linpath(G, X, n, endpoint=False)
Xuk = linpath(X, U, n // 4, endpoint=False)
Sigma = linpath(K, G, n, endpoint=True)
kpath=[Lambda,Delta,Xuk,Sigma]
bands = band_structure(parameters,nbs,kpath)

plt.figure(figsize=(15,10))
ax = plt.subplot(111)
plt.xlim(0, len(bands))
plt.ylim(min(bands[0]) - 1, max(bands[7]) + 1)
x_ticks=np.array([0, 0.5, 1, 1.5, 2, 2.25, 2.75, 3.25])*n
plt.xticks(x_ticks, ('$L$','$\Lambda$','$\Gamma$','$\Delta$','$X$','$U,K$','$\Sigma$','$\Gamma$'), fontsize=18)
plt.yticks(fontsize=18)
for y in np.arange(-25, 25, 2.5):
    plt.axhline(y, ls='--', lw=0.3, color='b',alpha=0.3)
plt.xlabel('k-path', fontsize=20)
plt.ylabel('Energy(eV)', fontsize=20)
ax.set_facecolor('white')
plt.grid(color='whitesmoke', linestyle='--', linewidth=2)
c =np.array(['black','c','gold','m','limegreen','royalblue','orange','red','brown','cyan'])
for band, color in zip(bands, c):
    plt.plot(band, lw=2.0, color=color)
plt.savefig('phy403.png')
#%%
from QuantumATK import *
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import math

# Read the complex bandstructure object from the NC file
cbs = nlread('si_100_cbs.nc', ComplexBandstructure)[-1]
energies = cbs.energies().inUnitsOf(eV)
k_real, k_complex = cbs.evaluate()
L = cbs.layerSeparation()

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# First plot the real bands
kvr = numpy.array([])
e = numpy.array([])

# Loop over energies, and pick those where we have solutions
for (j, energy) in enumerate(energies):
    k = k_real[j]*L/math.pi
    if len(k)>0:
        e = numpy.append(e,[energy,]*len(k))
        kvr = numpy.append(kvr,k)
        
# Plot the bands with red
ax.scatter([0.0,]*len(kvr), kvr, e, c='r', marker='o', linewidths=0, s=10)

# Next plot the complex bands
kvr = []
kvi = []
e = []

# Again loop over energies and pick solutions
for (j, energy) in enumerate(energies):
    if len(k_complex[j])>0:
        for x in numpy.array(k_complex[j]*L/math.pi):
            kr = numpy.abs(x.real)
            ki = -numpy.abs(x.imag)
            # Discard rapidly decaying modes which clutter the plot
            if ki>-0.3:
                e += [energy]
                kvr += [kr]
                kvi += [ki]

# Plot the complex bands with blue
ax.scatter(kvi, kvr, e, c='b', marker='o', linewidths=0, s=10)

# Put on labels
ax.set_xlabel('$\kappa$ (1/Ang)')
ax.set_ylabel('$kL/\pi$')
ax.set_zlabel('Energy / eV')

plt.show()
#%%
import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import matplotlib.gridspec as gs
import sys
 
#This function extracts the high symmetry points from the output of bandx.out
def Symmetries(fstring): 
  f = open(fstring,'r')
  x = np.zeros(0)
  for i in f:
    if "high-symmetry" in i:
      x = np.append(x,float(i.split()[-1]))
  f.close()
  return x
# This function takes in the datafile, the fermi energy, the symmetry file, a subplot, and the label
# It then extracts the band data, and plots the bands, the fermi energy in red, and the high symmetry points
def bndplot(datafile,fermi,symmetryfile,subplot,label):
  z = np.loadtxt(datafile) #This loads the bandx.dat.gnu file
  x = np.unique(z[:,0]) #This is all the unique x-points
  bands = []
  bndl = len(z[z[:,0]==x[1]]) #This gives the number of bands in the calculation
  Fermi = float(fermi)
  axis = [min(x),max(x),Fermi - 4, Fermi + 4]
  for i in range(0,bndl):
    bands.append(np.zeros([len(x),2])) #This is where we storre the bands
  for i in range(0,len(x)):
    sel = z[z[:,0] == x[i]]  #Here is the energies for a given x
    test = []
    for j in range(0,bndl): #This separates it out into a single band
      bands[j][i][0] = x[i]
      bands[j][i][1] = np.multiply(sel[j][1],13.605698066)
  for i in bands: #Here we plots the bands
    subplot.plot(i[:,0],i[:,1],color="black")
  temp = Symmetries(symmetryfile)
  for j in temp: #This is the high symmetry lines
    x1 = [j,j] 
    x2 = [axis[2],axis[3]]
    subplot.plot(x1,x2,'--',lw=0.55,color='black',alpha=0.75)
  subplot.plot([min(x),max(x)],[Fermi,Fermi],color='red',)
  subplot.set_xticklabels([])
  subplot.set_ylim([axis[2],axis[3]])
  subplot.set_xlim([axis[0],axis[1]])
  subplot.text((axis[1]-axis[0])/2.0,axis[3]+0.2,label,va='center',ha='center',fontsize=20)
  
  #%%
  from pythtb import * # import TB model class
import matplotlib.pyplot as plt

# read output from Wannier90 that should be in folder named "example_a"
#   see instructions above for how to obtain the example output from
#   Wannier90 for testing purposes
silicon=w90(r"example_a",r"silicon")

# get tight-binding model without hopping terms above 0.01 eV
my_model=silicon.model(min_hopping_norm=0.01)

# solve model on a path and plot it
path=[[0.5,0.5,0.5],[0.0,0.0, 0.0],[0.5,-0.5,0.0], [0.375,-0.375,0.0], [0.0, 0.0, 0.0]]
# labels of the nodes
k_label=(r'$L$', r'$\Gamma$',r'$X$', r'$K$', r'$\Gamma$')
# call function k_path to construct the actual path
(k_vec,k_dist,k_node)=my_model.k_path(path,101)
#
evals=my_model.solve_all(k_vec)
fig, ax = plt.subplots()
for i in range(evals.shape[0]):
    ax.plot(k_dist,evals[i],"k-")
for n in range(len(k_node)):
    ax.axvline(x=k_node[n],linewidth=0.5, color='k')
ax.set_xlabel("Path in k-space")
ax.set_ylabel("Band energy (eV)")
ax.set_xlim(k_dist[0],k_dist[-1])
ax.set_xticks(k_node)
ax.set_xticklabels(k_label)
fig.tight_layout()
fig.savefig("silicon_quick.pdf")
#%%
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 30 18:06:00 2020

@author: harshita
"""


from __future__ import print_function
from pythtb import * # import TB model class
import numpy as np
import matplotlib.pyplot as plt

# define lattice vectors
lat=[[2.73,2.73,0],[2.73,0,2.73],[0,2.73,2.73]]
# define coordinates of orbitals
orb=[[0,0,0],[0.25,0.25,0.25]]

# make two dimensional tight-binding graphene model
my_model1=tb_model(3,3,lat,orb)
my_model=my_model1.model(min_hopping_norm=0.01)


# set model parameters
delta=0.0
t=-1.0

# set on-site energies
my_model.set_onsite([-delta,delta])
# set hoppings (one for each connected pair of orbitals)
# (amplitude, i, j, [lattice vector to cell containing j])
#my_model.set_hop(t, 0, 1, [ 0, 0])
#my_model.set_hop(t, 1, 0, [ 1, 0])
#my_model.set_hop(t, 1, 0, [ 0, 1])

my_model.set_hop(-t, 0, 0, [1.0,0])
# y-hopping within sublattice of orbital "0"
my_model.set_hop(-t, 0, 0, [0,1.0])
# x-hopping within sublattice of orbital "1"
my_model.set_hop(-t, 1, 1, [1.0,0])
# y-hopping within sublattice of orbital "1"
my_model.set_hop(-t, 1, 1, [0,1.0])
# four inter-sublattice hopping terms, from "0" to "1"
my_model.set_hop(-t2, 0, 1, [0.0,0.0])
my_model.set_hop(-t2, 0, 1, [-1.0,0.0])
my_model.set_hop(-t2, 0, 1, [-1.0,-1.0])
my_model.set_hop(-t2, 0, 1, [0.0,-1.0])
# print tight-binding model
my_model.display()

# generate list of k-points following a segmented path in the BZ
# list of nodes (high-symmetry points) that will be connected
#path=[[0.,0.],[2./3.,1./3.],[.5,.5],[0.,0.]]
path=[[0.5,0.5,0.5],[0.0,0.0, 0.0],[0.5,-0.5,0.0], [0.375,-0.375,0.0], [0.0, 0.0, 0.0]]

# labels of the nodes
label=(r'$\Gamma $',r'$K$', r'$M$', r'$\Gamma $')
# total number of interpolated k-points along the path
nk=121
(k_vec,k_dist,k_node)=my_model.k_path(path,101)
# call function k_path to construct the actual path
#(k_vec,k_dist,k_node)=my_model.k_path(path,nk)
# inputs:
#   path, nk: see above
#   my_model: the pythtb model
# outputs:
#   k_vec: list of interpolated k-points
#   k_dist: horizontal axis position of each k-point in the list
#   k_node: horizontal axis position of each original node

print('---------------------------------------')
print('starting calculation')
print('---------------------------------------')
print('Calculating bands...')

# obtain eigenvalues to be plotted
evals=my_model.solve_all(k_vec)

# figure for bandstructure

fig, ax = plt.subplots()
# specify horizontal axis details
# set range of horizontal axis
ax.set_xlim(k_node[0],k_node[-1])
# put tickmarks and labels at node positions
ax.set_xticks(k_node)
ax.set_xticklabels(label)
# add vertical lines at node positions
for n in range(len(k_node)):
  ax.axvline(x=k_node[n],linewidth=0.5, color='k')
# put title
ax.set_title(" band structure")
ax.set_xlabel("Path in k-space")
ax.set_ylabel("Band energy")

# plot first and second band
ax.plot(k_dist,evals[0])
ax.plot(k_dist,evals[1])

# make an PDF figure of a plot
fig.tight_layout()
fig.savefig("graphene.pdf")

print('Done.\n')
#%%
from ATK.KohnSham import *

# Create Bravais lattice 
lattice_constant = 5.43*Angstrom
fcc_lattice = FaceCenteredCubic(lattice_constant)
